============================================================
RBCT 專用直升機遙測語音包 (RBCT Telemetry Voice Pack)
支援：繁體中文 (tw) / 簡體中文 (cn) / 英文 (en)
============================================================

【重要觀念說明 / Key Concept】
本資料夾（WIDGETS/RBCT/SOUND/）內已備妥 tw、cn、en 三套完整的 54 檔語音包，為發布暫存安裝檔。
遙控器 EdgeTX 系統在飛行運作時，只會直接讀取「記憶卡根目錄下的 /SOUNDS/」資料夾。
請飛友依照個人偏好語言，將本資料夾內的語音檔複製覆蓋到遙控器 SD 卡根目錄的 `/SOUNDS/` 對應語言目錄中！

【安裝步驟 / Installation Instructions】
1. 繁體中文用戶 (Traditional Chinese - 推薦 🌟)：
   * MK3 / EdgeTX 系統原生提供「繁體中文 (tw)」語音選項。
   * 若遙控器 SD 卡根目錄沒有 `SOUNDS/tw/`，建議先將 SD 卡根目錄的 `/SOUNDS/cn/` 複製一份並命名為 `/SOUNDS/tw/`（取得系統基礎數字報數字典）。
   * 將本資料夾內 `tw/` 中的所有 .wav 音檔，複製並「覆蓋」到遙控器 SD 卡根目錄的 `/SOUNDS/tw/` 下。
   * 遙控器長按【SYS】➔【Radio Setup】➔ 將【Voice Language】設定指向【tw】。

2. 簡體中文用戶 (Simplified Chinese)：
   * 將本資料夾內 `cn/` 中的所有 .wav 音檔，複製並「覆蓋」到遙控器 SD 卡根目錄的 `/SOUNDS/cn/` 下。
   * 遙控器長按【SYS】➔【Radio Setup】➔ 將【Voice Language】設定指向【cn】。

3. 英文語音用戶 (English)：
   * 將本資料夾內 `en/` 中的所有 .wav 音檔，複製並「覆蓋」到遙控器 SD 卡根目錄的 `/SOUNDS/en/` 下。
   * 遙控器長按【SYS】➔【Radio Setup】➔ 將【Voice Language】設定指向【en】。

【音檔清單與功能說明 / File List & Features】
- 50%.wav ~ 0%.wav      : 階梯電量百分比播報 (50%, 40%, 30%, 25%, 20%, 15%, 10%, 5%, 0%)
- batlow.wav / lowbat.wav: 電量過低警報 (Battery Low)
- batcrt.wav / dead.wav  : 臨界沒電警報 (Critical Battery / Land Immediately)
- bec_low.wav / rxbatlow.wav: BEC / 接收電壓過低警報 (BEC Low Voltage)
- bec_crit.wav / becovl.wav : BEC 電壓危險 / 負載過高 (BEC Critical / Overload)
- esct_warn.wav / telemwarn.wav: 電變溫度過高 (ESC Temp Warning)
- esct_crit.wav / overht.wav  : 電變嚴重過溫 (ESC Temp Critical)
- mcut_warn.wav / mcut_crit.wav: 飛控主板過溫警報 (MCU Temp Warning / Critical)
- escl_warn.wav / escl_crit.wav: 電變負載警告 / 超載 (ESC Current Warning / Overload)
- pwr_backup.wav / mainlost.wav: 主電源斷開，已切換備用電 (Main Power Lost)
- rescue_on.wav / rescue_off.wav: 救機模式開啟 / 關閉 (Rescue Mode ON / OFF)
- gov_on.wav / gov_off.wav      : 定速開啟 / 關閉 (Governor ON / OFF)
- motor_on.wav / motor_off.wav  : 馬達啟用 / 切斷 (Motor ON / OFF)
- armed.wav / disarm.wav        : 解鎖 / 上鎖 (Armed / Disarm)
- telem_lost.wav / telem_ok.wav : 遙測訊號丟失 / 恢復 (Telemetry Lost / Recovered)
- link_warn.wav / link_crit.wav : 連線訊號弱 / 危險 (Link Warning / Critical)
- rssi_warn.wav / rssi_crit.wav : 遙控信號弱 / 微弱 (RSSI Warning / Critical)
- gs_*.wav                      : 定速各種狀態語音 (Governor Statuses)

音檔規格：16,000 Hz, Mono (單聲道), 16-bit PCM WAV (EdgeTX / OpenTX 標準規格)
